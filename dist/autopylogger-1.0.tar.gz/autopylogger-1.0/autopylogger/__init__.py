
from autopylogger.autopylogger import *
__version__ = '1.0'
